
#ifndef NATIVE_LIB_H
#define NATIVE_LIB_H
int native_lib_main(std::string& name, std::string filename);
#endif // NATIVE_LIB_H
